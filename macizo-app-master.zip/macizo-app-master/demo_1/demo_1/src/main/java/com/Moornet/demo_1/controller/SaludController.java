package com.Moornet.demo_1.controller;


import com.Moornet.demo_1.entity.Salud;
import com.Moornet.demo_1.entity.Usuario;
import com.Moornet.demo_1.service.SaludService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RequestMapping("/macizoapp/salud")
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@AllArgsConstructor
public class SaludController {
    private final SaludService saludService;

  @GetMapping
  public Iterable<Salud> getSaludList(){
   return saludService.getTodaLaSalud();
  }


  @ResponseStatus(HttpStatus.CREATED)
  @PostMapping
  public Salud nuevaSalud(@RequestBody Salud salud){
    return saludService.guardarSalud(salud);
  }
  @GetMapping("{id}")
  public Salud getI(Integer id) throws Exception {
    return saludService.findById(id);
  }
}
