package com.Moornet.demo_1.repository;

import com.Moornet.demo_1.entity.Salud;
import org.springframework.data.repository.CrudRepository;

public interface SaludRepository extends CrudRepository<Salud,Integer> {
}
