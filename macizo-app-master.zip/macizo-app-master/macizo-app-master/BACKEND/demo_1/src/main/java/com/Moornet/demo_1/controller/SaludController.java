package com.Moornet.demo_1.controller;


import com.Moornet.demo_1.entity.Salud;
import com.Moornet.demo_1.entity.Usuario;
import com.Moornet.demo_1.service.SaludService;
import com.Moornet.demo_1.service.UsuarioService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RequestMapping("/macizoapp/salud")
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@AllArgsConstructor
public class SaludController {
  private final SaludService saludService;

  @Autowired
  private UsuarioService usuarioser;


  @GetMapping
  public Iterable<Salud> getSaludList() {
    return saludService.getTodaLaSalud();
  }


 /* @PostMapping
  public Salud nuevaSalud(@RequestBody Map<String, Object> datosSalud)  throws Exception {
    Integer idUsuario = (Integer) datosSalud.get("id_usuario_frg");
    Usuario usuario = usuarioser.findById(idUsuario);

    Salud nuevaSalud = new Salud();
    nuevaSalud.setId_usuario_frg(usuario);
    nuevaSalud.setPeso((Float) datosSalud.get("peso"));
    nuevaSalud.setAltura((Float) datosSalud.get("altura"));
    nuevaSalud.setImc((Float) datosSalud.get("imc"));
    // Otros campos según sea necesario

    Salud guardada = saludService.guardarSalud(nuevaSalud);
  }
*/
  @GetMapping("{id}")
  public Salud getI(Integer id) throws Exception {
    return saludService.findById(id);
  }

  @PutMapping("{id}")
  public Salud updateSalud(@PathVariable Integer id_salud, @RequestBody Salud salud) throws Exception {
    return saludService.updateSalud(id_salud, salud);
  }
}
